create function get_movie(p_title character varying)
    returns TABLE(movie_id integer, movie_title character varying, movie_year integer, movie_returnvalue integer)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY SELECT
		id,
		title,
		year,
		returnvalue
	FROM
		moviesearch
	WHERE
		title ILIKE p_title ;
END;
$$;

alter function get_movie(varchar) owner to postgres;

